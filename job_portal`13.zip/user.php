<?php
session_start();
if(isset($_SESSION['user_id'])){


}else{
  header('location:user_login.php?ss');

}



 ?>

<?php
include("connection/db.php");
include("connection/db.php");
$user_id=$_SESSION['user_id'];


$user_query=mysqli_query($dbconnect,"SELECT * from user where `user_id`='$user_id'");
 
while($userProfieData=mysqli_fetch_assoc($user_query)){
$id=$userProfieData['id'];
$user_name=$userProfieData['user_name'];
$user_email=$userProfieData['user_email'];
$user_phone=$userProfieData['user_phone'];
$date_of_birth=$userProfieData['date_of_birth'];
$user_addrs=$userProfieData['user_address'];
$user_gender=$userProfieData['gender'];
// $user_skill=$userProfieData['skill'];
$agent_ref_id=$userProfieData['ref_id'];
$Date=$userProfieData['Date'];
}

$user_education_query=mysqli_query($dbconnect,"SELECT * from education where `user_id`='$user_id'");

$user_work_query=mysqli_query($dbconnect,"SELECT * from work_experiance where `user_id`='$user_id'");


include("include/header.php");
?>
  <body>
    
	   <?php
     include("include/nav.php")
     ?>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-xl-10 ftco-animate mb-5 pb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="mb-4 mt-5 pt-5" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">We have <span class="number" data-number="850000">0</span> great job offers you deserve!</p>
            <h1 class="mb-5" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">BD TRUSTH JOB  <br><span> Your Job is Waiting</span></h1>

					
          </div>
        </div>
      </div>
    </div>


 
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-9">
          <div class="row align-items-center">
            <div class="col-lg-5">
              <div class="resume-base bg-success user-dashboard-info-box p-4">
                <div class="profile">
                  <div class="jobster-user-info">
                    <div class="profile-avatar">
                      <img class="img-fluid " src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="">
                    </div>
                    <div class="profile-avatar-info mt-3">
                      <h5 class="text-dark h2 "> <a  style="color:black" class="text-white" href="">User Dashboard </a></h5>
                      <h6 class="text-dark h2 "> <a  style="color:black" class="text-white" href="user_signout.php">SIGN OUT  </a></h6>
                    </div>
                  </div>
                </div>
                <div class="about-candidate border-top">
                  <div class="candidate-info">
                    <h6 class="text-dark h5  "><span class="text-white text-bold ">Name </span>: <?php echo $user_name ?></h6>
                    
                  </div>
                  <div class="candidate-info">
                    <h6 class="text-dark h5 ">  <span class="text-white text-bold ">Email</span>: <?php echo $user_email ?> </h6>
                    
                  </div>
                  <div class="candidate-info">
                    <h6 class="text-dark h5 "><span class="text-white text-bold ">Phone</span>: <?php echo $user_phone  ?> </h6>
                    

                  </div>
                  <div class="candidate-info">
                    <h6 class="text-dark h5 "><span class="text-white" style="" >Date Of Birth</span>: <?php echo $date_of_birth ?> </h6>
                    
                  </div>
                  <div class="candidate-info">
                    <h6 class="text-white h5"><span class="text-white text-bold ">Address </span>:   </h6>
                    <p class="text-dark h5 "> <?php echo $user_addrs  ?> </p>
                  </div>
                  <div class="candidate-info">
                    <h6 class="text-dark h5 "><span class="text-white bold "> Gender</span>: <?php echo $user_gender  ?> </h6>
                    
                  </div>
                </div>
                <div class="mt-0">
                  <h5 class="text-white">Professional Skill:</h5>
                  <div class="">
                   <h5 class="h4" ><pre><?php  ?></pre> </h5>
                  </div>
                 
                
                </div>
              </div>
            </div>
            <div class="col-lg-7">
              <div class="resume-experience">
                <div class="timeline-box">
                  <h5 class="resume-experience-title">Education:</h5>
                  <div class="jobster-candidate-timeline">
                  <?php while ($user_education_data = mysqli_fetch_assoc($user_education_query)) { ?>
                    <div class="jobster-timeline-item">
                      <div class="jobster-timeline-cricle">
                        <i class="far fa-circle"></i>
                      </div>
                      <div class="jobster-timeline-info">
                        <div class="dashboard-timeline-info">
                          <span class="jobster-timeline-time"> <?php echo htmlspecialchars($user_education_data['education_year']); ?> </span>
                          <h6 class="mb-2">  <?php echo htmlspecialchars($user_education_data['degree']); ?> </h6>
                          <h6 class="mb-2" style="text-transform: uppercase;" > <span style="font-weight: 900;" class="text-dark" > GPA / CGPA : </span> <?php echo htmlspecialchars($user_education_data['education_result']); ?>  </h6>
                          <span style="font-weight: 900; text-transform: uppercase;" class="h6"> <?php echo htmlspecialchars($user_education_data['institution']); ?>  </span>
                        
                        </div>
                      </div>
                    </div>

                    <?php } ?>
                   
                  </div>
                </div>
                <div class="timeline-box mt-4">
                  <h5 class="resume-experience-title">Work &amp; Experience:</h5>
                  <div class="jobster-candidate-timeline">
                  <?php while ($user_work_data = mysqli_fetch_assoc($user_work_query)) { ?>
                    <div class="jobster-timeline-item">
                      <div class="jobster-timeline-cricle">
                        <i class="far fa-circle"></i>
                      </div>
                 

                      <div class="jobster-timeline-info">
                        <div class="dashboard-timeline-info">
                          <span class="jobster-timeline-time"> <?php echo htmlspecialchars($user_work_data['experiance_date']); ?></span>
                          <h6 class="mb-2">   <?php echo htmlspecialchars($user_work_data['w_experiance_position']); ?> </h6>
                          <span style="text-transform: uppercase;font-weight:600;" class="text-dark" >-  <?php echo htmlspecialchars($user_work_data['w_experiance_institution']); ?></span>
                          <p class="mt-2">   <?php echo htmlspecialchars($user_work_data['experiance_details']); ?> </p>
                        </div>
                      </div>

                     
                    </div>
                    <?php } ?>
                 
                  </div>
                </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  

 
		




 
		
	
   <?php
   include("include/footer.php")
   ?>
   