<?php
include("connection/db.php");
 $company_name=$_POST['company_name'];
 $company_email=$_POST['company_email'];
 $company_pass=$_POST['company_pass'];
 $company_phone=$_POST['company_phone'];
 $company_addrs=$_POST['company_addrs'];
 $company_category=$_POST['company_category'];
 $company_agent_ref=$_POST['agent_ref'];
 
$query =mysqli_query($dbconnect,"INSERT INTO company (company_name , company_email,company_pass,
company_phone,company_addrs,company_category,ref_id) VALUES  ('$company_name','$company_email','$company_pass','$company_phone','$company_addrs',
'$company_category','$company_agent_ref')") ;

if ($query){
   
    header("location:company_login.php?com_reg_success");
} else {
    echo " <div class='alert alert-danger'> some error please try again </div>  ";
    header("location:company_reg.php?c_reg_faild");
}

?> 