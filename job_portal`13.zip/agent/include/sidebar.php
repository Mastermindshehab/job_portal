<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
         

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm d-flex align-items-center justify-content-center"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
          <li class="menu-item">
              <a
                href="../include/../company_singout.php"
                target="_blank"
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-log-out-circle"></i>
                <div class="text-truncate" data-i18n="Email">Sign Out</div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="../agent/../agent_profile.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" > View Agent  Profile  </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="../agent/contact_info.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >Update Contact info </div>
               
              </a>
            </li>
            
            <li class="menu-item active open  ">
              <a
                href=""
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >Agent Personal  Post </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="../agent/agent_withdraw.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" > withdraw </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="withdraw_history.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" > transaction history </div>
               
              </a>
            </li>
            
      
            <!-- Dashboards -->
       
            <!-- Layouts -->
          

            <!-- Front Pages -->
            

            <!-- Apps & Pages -->
            
           
          
            
            
            <!-- Pages -->
           
            <!-- Components -->
            

       

          

          
         
         
           
           
            <!-- Tables -->
           
            <!-- Data Tables -->
            
            <!-- Misc -->
           
            
          </ul>
        </aside>

 