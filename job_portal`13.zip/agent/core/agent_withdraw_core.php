<?php
session_start();
include("connection/db.php");

// Ensure that the session is set
if (!isset($_SESSION['agent_username'])) {
    header("location:../../agent_login.php"); // Redirect to login if session is not set
    exit();
}

// Fetch the admin's details
$admin_query = mysqli_query($dbconnect, "SELECT * FROM admin_login");
$adminData = mysqli_fetch_assoc($admin_query);
$admin_id = $adminData['admin_email'];

// Retrieve agent's session details
$agent_id = $_SESSION['agent_username'];
// $agent_name = $_REQUEST['agent_name']; // Make sure that 'agent_name' is passed in the request
// echo $agent_id;
// echo $agent_name;
// echo $admin_id;

if (isset($_POST['agent_to_adminBtn'])) {
    // Get form inputs for the transfer

    $agent_name = mysqli_real_escape_string($dbconnect, $_POST['agent_name']);
    $payment_option = mysqli_real_escape_string($dbconnect, $_POST['payment_option']);
    $payment_number = mysqli_real_escape_string($dbconnect, $_POST['payment_number']);
    $transfer_amount = mysqli_real_escape_string($dbconnect, $_POST['transfer_amount']);

    // Check agent's balance
    $search = "SELECT * FROM agent WHERE `agent_id` = '$agent_id' LIMIT 1";
    $search_result = mysqli_query($dbconnect, $search);
    $result = mysqli_fetch_assoc($search_result);

    if ($result) { // Ensure result is found
        // Check if agent has sufficient balance
        if ($result['agent_balance'] == 0 || $result['agent_balance'] < $transfer_amount) {
            echo "<script> alert('Insufficient Balance!'); </script>";
            header('location:../agent_withdraw.php?insufficient');
            exit();
        } else {
            // Find admin account details
            $find_to_account = "SELECT * FROM admin_login WHERE `admin_email` = '$admin_id' LIMIT 1"; 
            $search_acc = mysqli_query($dbconnect, $find_to_account);
            $to_result = mysqli_fetch_assoc($search_acc);

            if ($to_result) {
                // Add funds to admin's balance
                $total_amount_after_add = $to_result['admin_balance'] + $transfer_amount;
                $add_fund = "UPDATE admin_login SET admin_balance = '$total_amount_after_add' WHERE `admin_email` = '$admin_id'";
                $done_adding_fund = mysqli_query($dbconnect, $add_fund);

                // Subtract funds from agent's balance
                $total_amount_after_subtract = $result['agent_balance'] - $transfer_amount;
                $subtract_fund = "UPDATE agent SET agent_balance = '$total_amount_after_subtract' WHERE `agent_id` = '$agent_id'";
                $done_subtracting_fund = mysqli_query($dbconnect, $subtract_fund);

                // Add transaction record
                $add_trans_record = "INSERT INTO admin_t_history (`agent_id`,`agent_name`, `admin_id`, `transfer_amount`, `payment_option`, `payment_number`) 
                                     VALUES ('$agent_id', '$agent_name' , '$admin_id', '$transfer_amount', '$payment_option', '$payment_number')";
                mysqli_query($dbconnect, $add_trans_record);

                // Check if both fund addition and subtraction were successful
                if ($done_adding_fund && $done_subtracting_fund) {
                    echo "<script> alert('Fund Transferred Successfully!'); </script>";
                    header('location:../agent_withdraw.php?transfer_Success');
                } else {
                    echo "<script>alert('Fund Transfer Failed!');</script>";
                    header('location:../agent_withdraw.php?transfer_fail');
                }
            } else {
                echo "<script>alert('Admin Account Not Found!');</script>";
            }
        }
    } else {
        echo "<script>alert('Agent Not Found!');</script>";
    }
}
?>
