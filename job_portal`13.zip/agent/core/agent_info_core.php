<?php
session_start();
include("connection/db.php");

// Ensure that session is set
if (!isset($_SESSION['agent_username'])) {
    header("location:../../agent_login.php"); // Redirect to login if session is not set
    exit();
}

$agent_id = mysqli_real_escape_string($dbconnect, $_SESSION['agent_username']);
$agent_name = mysqli_real_escape_string($dbconnect, $_POST['agent_name']);
$agent_phone = mysqli_real_escape_string($dbconnect, $_POST['agent_phone']);
$agent_division = mysqli_real_escape_string($dbconnect, $_POST['agent_division']);
$agent_district = mysqli_real_escape_string($dbconnect, $_POST['agent_district']);
$agent_s_district = mysqli_real_escape_string($dbconnect, $_POST['agent_s_district']);


$query = mysqli_query($dbconnect, "UPDATE agent 
SET 
    agent_name = '$agent_name', 
    agent_phone = '$agent_phone', 
    agent_division = '$agent_division', 
    agent_district = '$agent_district',
    agent_s_district = '$agent_s_district'  
WHERE agent_id = '$agent_id'");

if ($query) {
    header("location:../contact_info.php?com_Update_success");
    exit();
} else {
    header("location:../contact_info.php?c_Update_failed");
    exit();
}
?>
