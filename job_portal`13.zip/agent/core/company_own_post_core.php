<?php
session_start();
include("connection/db.php");

// Ensure that session is set
if (!isset($_SESSION['company_email'])) {
    header("location:../../company_login.php"); // Redirect to login if session is not set
    exit();
}

$company_email = $_SESSION['company_email'];

// Retrieve company_id based on company_email
$company_query = mysqli_query($dbconnect, "SELECT company_id FROM company WHERE company_email='$company_email'");
$companyprofiledata = mysqli_fetch_assoc($company_query);
$company_id = $companyprofiledata['company_id'];

// Handle file upload
$c_post_image = $_FILES["upload_images"]["name"];
$c_post_tmpName = $_FILES["upload_images"]["tmp_name"];
$imgLocation = "../img/";
$imageFileType = strtolower(pathinfo($c_post_image, PATHINFO_EXTENSION));

// Generate a unique file name and define the target path
$nameForimg = uniqid() . "." . $imageFileType;
$target_file = $imgLocation . $nameForimg;

// Check if file is an actual image and move the uploaded file
$check = getimagesize($c_post_tmpName);
if ($check !== false) {
    if (move_uploaded_file($c_post_tmpName, $target_file)) {
        // Prepare data for insertion
        $c_post_title = mysqli_real_escape_string($dbconnect, $_POST['post_title']);
        $c_post_desc = mysqli_real_escape_string($dbconnect, $_POST['post_desc']);

        // Insert data into the database
        $query = "INSERT INTO company_post (post_title, post_photo, post_content, company_id) 
                  VALUES ('$c_post_title', '$nameForimg', '$c_post_desc', '$company_id')";

        if (mysqli_query($dbconnect, $query)) {
            header("location:../company_own_post.php?com_Update_success");
            exit();
        } else {
            header("location:../company_own_post.php?c_Update_failed");
            exit();
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
} else {
    echo "File is not an image.";
}

mysqli_close($dbconnect);
?>
