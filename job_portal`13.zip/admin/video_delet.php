<?php
require_once('../admin/../connection/db.php');
$y_del=$_GET['del'];

$dlt_query=mysqli_query($dbconnect," DELETE FROM youtube_video1 WHERE id='$y_del' ");;

 if ($dlt_query){
   echo "<script> alert ('data delet has been successfully') </script>";
   header("location:youtube_video.php");

}else{
    echo "<script> alert ('data delet has been Not successfully') </script>";
}


?>