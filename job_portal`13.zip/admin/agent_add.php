
<?php
// Include the database connection file
include("../connection/db.php");

// Retrieve data from the POST request
$agent_email = $_POST['agent_email'];
$agent_name = $_POST['agent_name'];
$agent_username = $_POST['agent_username'];
$agent_password = $_POST['agent_password'];
$agent_division = $_POST['agent_division'];
$agent_district = $_POST['agent_district'];
$agent_s_district = $_POST['agent_s_district'];
$agent_ref = $_POST['agent_ref'];
$agent_balance = $_POST['agent_balance'];


// Prepare the SQL query
$query = mysqli_query($dbconnect, "INSERT INTO agent (agent_email, agent_name, agent_id, agent_password, agent_division, agent_district, agent_s_district,agent_ref, agent_balance  ) 
VALUES ('$agent_email', '$agent_name', '$agent_username', '$agent_password', '$agent_division', '$agent_district', '$agent_s_district', '$agent_ref','$agent_balance')");

// Execute the query and provide feedback
if ($query) {
    echo "<div class='alert alert-success'> Data has been successfully inserted. </div>";
} else {
    echo "<div class='alert alert-danger'> Some error occurred, please try again. </div>";
}
?>
