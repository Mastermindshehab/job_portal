<?php
include("include/header.php")
?>
  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

       <?php
       include("include/sidebar.php")
       ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
          <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar" aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="user.php">Users</a></li>
    <li class="breadcrumb-item active" aria-current="page"><a href="add_user.php">Add Users</a> </li>
  </ol>
</nav>

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar">
            
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
                <i class="bx bx-menu bx-md"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <h1> Add Videos Link  </h1>
              </div>
              <!-- /Search -->
              
              
              

              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- Place this tag where you want the button to render. -->
            
                   
                <!-- User -->
             
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl  flex-grow-1 container-p-y">
            <div class="row">
           
           <div class="col-md-12">
             <div class="card">
               <div class="card-header card-header-primary">
                 <h4 class="card-title"></h4>
                 <p class="card-category text-center ">Agent Add form </p>
               </div>
               <div id="id">

               </div>
               <div class="card-body">
                 <form method="POST" action="" name="video_form" id="video_form" >
                   <div class="row">
                    
                     <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating"> Youtube Videos Link </label>
                         <input placeholder="your vidoe link " name="videos" id="youtube_video1" type="text" class="form-control" required>
                       </div>
                     </div>
                   
                   </div>

                  <button name="submit" type="submit" id="submit" class="btn btn-primary pull-right"> Add agent </button>

                   <div class="clearfix"></div>
                 </form>
               </div>
             </div>
           </div>
           
         </div>
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl">
                <div
                  class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
                  <div class="text-body">
                    ©
                    <script>
                      document.write(new Date().getFullYear());
                    </script>
                    , made with ❤️ by
                    <a href="https://www.facebook.com/profile.php?id=100011410499291" target="_blank" class="footer-link">Mastermind Shehab</a>
                  </div>
                 
                </div>
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

   

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/js/menu.js"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>
    <!-- Data Tablels Plugin -->
     <script src="https://code.jquery.com/jquery-3.7.1.js" > </script>
     <script src="https://cdn.datatables.net/2.1.4/js/dataTables.js" > </script>
     
     <script>
        $(document).ready(function(){
            $('#example ').DataTable();
        })
     </script>

     <script>
     $(document).ready(function(){
   $("#submit").click(function (event){
      event.preventDefault(); // Prevent the form from submitting normally
       
      var data = $("#video_form").serialize();
      $.ajax({
         type: "POST",
         url: "youtube_v_add.php",
         data: data,
         success: function(data){
            alert(data); // Show the response in an alert
         },
         error: function(xhr, status, error){
            // alert("An error occurred: " + error); 
            console.log(error)// Handle errors
         }
      });
   });
});

     </script>

  </body>
</html>

