<?php
require_once('../admin/../connection/db.php');
$n_del1=$_GET['del1'];

$dlt_query1=mysqli_query($dbconnect," DELETE FROM s_notice1 WHERE id='$n_del1' ");;

 if ($dlt_query1){
   echo "<script> alert ('data delet has been successfully') </script>";
   header("location:notice_page.php");

}else{
    echo "<script> alert ('data delet has been Not successfully') </script>";
}


?>

<?php
require_once('../admin/../connection/db.php');
$n_del2=$_GET['del2'];

$dlt_query2=mysqli_query($dbconnect," DELETE FROM s_notice2 WHERE id='$n_del2' ");;

 if ($dlt_query2){
   echo "<script> alert ('data delet has been successfully') </script>";
   header("location:notice_page.php");

}else{
    echo "<script> alert ('data delet has been Not successfully') </script>";
}


?>