
<?php
// Include the database connection file
include("../connection/db.php");

// Retrieve data from the POST request
$youtube_videos=$_POST['videos'];


// Prepare the SQL query
$query = mysqli_query($dbconnect, "INSERT INTO youtube_video1 (video_link) 
VALUES ('$youtube_videos')");

// Execute the query and provide feedback
if ($query) {
    echo "<div class='alert alert-success'> Data has been successfully inserted. </div>";
} else {
    echo "<div class='alert alert-danger'> Some error occurred, please try again. </div>";
}
?>
