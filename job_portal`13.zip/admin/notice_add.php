
<?php
// Include the database connection file
include("../connection/db.php");

// Retrieve data from the POST request
$first_notice_text = $_POST['first_notice_text'];

// Prepare the SQL query
$query = mysqli_query($dbconnect, "INSERT INTO s_notice1 (notice) 
VALUES ('$first_notice_text')");

// Execute the query and provide feedback
if ($query) {
    echo "<div class='alert alert-success'> Data has been successfully inserted. </div>";
} else {
    echo "<div class='alert alert-danger'> Some error occurred, please try again. </div>";
}
?>


<?php

