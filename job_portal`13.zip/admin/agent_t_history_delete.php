<?php
require_once('../admin/../connection/db.php');
$y_del=$_GET['delt'];

$dlt_query=mysqli_query($dbconnect," DELETE FROM admin_t_history WHERE id='$y_del' ");;

 if ($dlt_query){
  
   header("location:agent_withdraw_history.php?succes_delt");

}else{
    echo "<script> alert ('data delet has been Not successfully') </script>";
}


?>