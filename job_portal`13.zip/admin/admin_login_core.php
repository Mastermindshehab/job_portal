<?php
require_once('../admin/../connection/db.php');


$admin_email=$_REQUEST['admin_email'];
$admin_pwt=$_REQUEST['admin_pass'];




$admin_Login_query=mysqli_query($dbconnect,"SELECT * FROM `admin_login` where  `admin_email`='$admin_email' and `admin_pass`='$admin_pwt' ");

if(mysqli_num_rows($admin_Login_query)==1){
    session_start();

    $_SESSION['session_id']=session_id();
    $_SESSION['admin_email']=$admin_email;
    $_SESSION['admin_pass']=$admin_pwt;

    header('Location: admin_dashboard.php');

 
}else{
    header('Location: index.php?adminLerror!');


}

?>