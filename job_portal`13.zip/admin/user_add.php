<?php
include("../admin/../connection/db.php");
 $email=$_POST['user_email'];
 $username=$_POST['user_id'];
 $password=$_POST['password'];
 $user_fName=$_POST['user_firstName'];
 $user_lName=$_POST['user_last_name'];
 $admin_type=$_POST['user_type'];

$query =mysqli_query($dbconnect,"INSERT INTO admin_login (admin_email , admin_pass,admin_username,
first_name,last_name,admin_type) VALUES  ('$email','$username','$password','$user_fName','$user_lName',
'$admin_type')") ;

if ($query){
    echo " <div class='alert alert-success'> Data has been successfully Inserted </div> ";
} else {
    echo " <div class='alert alert-danger'> some error please try again </div>  ";
}

?> 