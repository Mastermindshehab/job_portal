<?php
 include('../admin/../connection/db.php');

 if (isset($_GET['approve'])) {
    $pending_user_id = $_GET['approve'];
 
    $agent_query=mysqli_query($dbconnect,"SELECT * from pending_users where `id`='$pending_user_id'");
     
    while($agentProfileData=mysqli_fetch_assoc($agent_query)){
    $pending_id=$agentProfileData['id'];
    $user_name=$agentProfileData['user_name'];
    $user_email=$agentProfileData['user_email'];
    $user_id=$agentProfileData['user_id'];
    $user_pass=$agentProfileData['user_pass'];
    $user_phone=$agentProfileData['user_phone'];
    $user_date_of_birth=$agentProfileData['date_of_birth'];
    $user_addrs=$agentProfileData['user_address'];
    $user_gender=$agentProfileData['gender'];
    $user_payment_amount=$agentProfileData['payment_amount'];
    $user_payment_number=$agentProfileData['payment_number'];
    $ref_id=$agentProfileData['ref_id'];
    $Date=$agentProfileData['Date'];
    }

    // Insert the new user into the 'user' table
$query = mysqli_query($dbconnect, "INSERT INTO user (user_name, user_email, user_id, user_pass, user_phone,date_of_birth,user_address,gender,payment_amount,payment_number, ref_id) 
VALUES ('$user_name', '$user_email', '$user_id', '$user_pass', '$user_phone', '$user_date_of_birth' , '$user_addrs' , '$user_gender' , '$user_payment_amount' , '$user_payment_number','$ref_id')");

// Check if the user was successfully inserted
if ($query) {
    // First level commission: 80 Taka to the first agent
    $level1_query = mysqli_query($dbconnect, "UPDATE agent SET agent_balance = agent_balance + 80 WHERE agent_id = '$ref_id'");

    // Get the referrer_id of the first agent for the second level commission
    $level2_result = mysqli_query($dbconnect, "SELECT agent_ref FROM agent WHERE agent_id = '$ref_id'");
    $level2_data = mysqli_fetch_assoc($level2_result);
    $level2_ref_id = $level2_data['agent_ref'];

    if ($level2_ref_id) {
        // Second level commission: 10 Taka to the second agent
        $level2_query = mysqli_query($dbconnect, "UPDATE agent SET agent_balance = agent_balance + 10 WHERE agent_id = '$level2_ref_id'");

        // Get the referrer_id of the second agent for the third level commission
        $level3_result = mysqli_query($dbconnect, "SELECT agent_ref FROM agent WHERE agent_id = '$level2_ref_id'");
        $level3_data = mysqli_fetch_assoc($level3_result);
        $level3_ref_id = $level3_data['agent_ref'];

        if ($level3_ref_id) {
            // Third level commission: 10 Taka to the third agent
            $level3_query = mysqli_query($dbconnect, "UPDATE agent SET agent_balance = agent_balance + 10 WHERE agent_id = '$level3_ref_id'");


        }

        

    }

    // Remove the approved user from the 'pending_users' table
$delete_pending_user = mysqli_query($dbconnect, "DELETE FROM pending_users WHERE id = '$pending_user_id'");

header('location:pending_list.php?sucess');
exit();

}
   

} else {
    echo "No user ID provided.";
}
?>
