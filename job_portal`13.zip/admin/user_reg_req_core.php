<?php
require_once('../admin/../connection/db.php');
$user_name = $_REQUEST['user_name'];
$user_email = $_REQUEST['user_email'];
$user_id = $_REQUEST['user_id'];
$user_pass = $_REQUEST['user_pass'];
$user_phone = $_REQUEST['user_phone'];
$user_date_of_birth = $_REQUEST['user_date_of_birth'];
$user_addrs = $_REQUEST['user_addrs'];
$user_gender = $_REQUEST['user_gender'];
$user_payment_amount = $_REQUEST['user_payment_amount'];
$user_payment_confirm_number = $_REQUEST['u_payment_c_number'];
$ref_id = $_REQUEST['ref_id'];
 

// Insert the new user data into the 'pending_users' table
$query = mysqli_query($dbconnect, "INSERT INTO pending_users (user_name, user_email, user_id, user_pass, user_phone,date_of_birth,user_address,gender,payment_amount,payment_number,ref_id) 
VALUES ('$user_name', '$user_email', '$user_id', '$user_pass', '$user_phone','$user_date_of_birth', '$user_addrs', '$user_gender', '$user_payment_amount'  , '$user_payment_confirm_number' ,  '$ref_id')");

if ($query) {
   
    header("location: ../user_reg.php?userReqPending_success");
} else {
    echo "Failed to submit registration. Please try again.";
    header("location:../user_reg.php?errorUserReq");
}
?>