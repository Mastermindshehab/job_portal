<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
         

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm d-flex align-items-center justify-content-center"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
          <li class="menu-item">
              <a
                href="admin_logout.php"
                target="_blank"
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-log-out-circle"></i>
                <div class="text-truncate" data-i18n="Email">Sign Out</div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="user.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >User</div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="agent.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >Agent</div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="notice_page.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >Notice Option </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="youtube_video.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >Youtube Video Link  </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="pending_list.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" > user pending list   </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="company_list.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >company   </div>
               
              </a>
            </li>
            <li class="menu-item active open  ">
              <a
                href="agent_withdraw_history.php"
               
                class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" >agent Transaciton history   </div>
               
              </a>
            </li>
            <!-- Dashboards -->
            <li class="menu-item   ">
              <a href="admin_dashboard.php" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-home-smile"></i>
                <div class="text-truncate" >Dashboards</div>
                <span class="badge rounded-pill bg-danger ms-auto">5</span>
              </a>
              <ul class="menu-sub">
                <li class="menu-item active">
                  <a href="index.html" class="menu-link">
                    <div class="text-truncate" data-i18n="Analytics">Analytics</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a
                    href=""
                    target="_blank"
                    class="menu-link">
                    <div class="text-truncate" data-i18n="CRM">CRM</div>
                    <div class="badge rounded-pill bg-label-primary text-uppercase fs-tiny ms-auto">Pro</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a
                    href=""
                    class="menu-link">
                    <div class="text-truncate" data-i18n="eCommerce">eCommerce</div>
                    <div class="badge rounded-pill bg-label-primary text-uppercase fs-tiny ms-auto">Pro</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a
                    href=""
                    target="_blank"
                    class="menu-link">
                    <div class="text-truncate" data-i18n="Logistics">Logistics</div>
                    <div class="badge rounded-pill bg-label-primary text-uppercase fs-tiny ms-auto">Pro</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="" target="_blank" class="menu-link">
                    <div class="text-truncate" data-i18n="Academy">Academy</div>
                    <div class="badge rounded-pill bg-label-primary text-uppercase fs-tiny ms-auto">Pro</div>
                  </a>
                </li>
              </ul>
            </li>

            <!-- Layouts -->
          

            <!-- Front Pages -->
            

            <!-- Apps & Pages -->
            
           
          
            
            
            <!-- Pages -->
           
            <!-- Components -->
            

       

          

          
         
         
           
           
            <!-- Tables -->
           
            <!-- Data Tables -->
            
            <!-- Misc -->
           
            
          </ul>
        </aside>

 