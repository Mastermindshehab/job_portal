<?php
include("include/header.php")
?>
  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

       <?php
       include("include/sidebar.php")
       ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
          <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar" aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="admin_dashboard.php">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="user.php">Users</a></li>
    <li class="breadcrumb-item active" aria-current="page"><a href="add_user.php">Add Users</a> </li>
  </ol>
</nav>

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar">
            
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
                <i class="bx bx-menu bx-md"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <h1> Add Agent </h1>
              </div>
              <!-- /Search -->
              
              
              

              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- Place this tag where you want the button to render. -->
            
                   
                <!-- User -->
             
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl  flex-grow-1 container-p-y">
            <div class="row">
           
           <div class="col-md-12">
             <div class="card">
               <div class="card-header card-header-primary">
                 <h4 class="card-title"></h4>
                 <p class="card-category text-center ">Agent Add form </p>
               </div>
               <div id="id">

               </div>
               <div class="card-body">
                 <form method="POST" action="" name="agent_form" id="agent_form" >
                   <div class="row">
                    
                     <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating"> Agent  Email </label>
                         <input placeholder="User Email" name="agent_email" id="agent_email" type="email" class="form-control" required>
                       </div>
                     </div>
                   
                   </div>
                   <div class="row">

                     <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">Agent Name </label>
                         <input placeholder="agent name   here .." name="agent_name" id="agent_name" type="text" class="form-control" required >
                       </div>
                     </div>
                    
                   
                   
                   </div>
                   <div class="row">

<div class="col-md-12">
  <div class="form-group">
    <label class="bmd-label-floating">Agent Username  </label>
    <input placeholder="agent username   here .." name="agent_username" id="agent_username" type="text" class="form-control" required >
  </div>
</div>



</div>
                   <div class="row">

                     <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">password </label>
                         <input placeholder="pass  here .." name="agent_password" id="agent_password" type="password" class="form-control" required >
                       </div>
                     </div>
                    
                   
                   
                   </div>
                   <div class="row">
                       <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">Select Division   </label>
                         <br>

                         <select name="agent_division" id="agent_division">
                             <option value="dhaka">Dhaka</option>
                             <option value="Khulna">Khulna</option>
                             <option value="Rajshahi">Rajshahi</option>
                             <option value="Rangpur">Rangpur</option>
                             <option value="Mymensingh ">Mymensingh </option>
                             <option value="Sylhet">Sylhet</option>
                             <option value="Chattogram">Chattogram</option>
                             <option value="Barishal">Barishal</option>
                             

                        </select>

                       </div>
                     </div>
                 
                   </div>

                   <div class="row">
                       <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">Select District   </label>
                         <br>

                         <select name="agent_district" id="agent_district">
                             <option value="Barguna">Barguna</option>
                             <option value="Barishal">Barishal</option>
                             <option value="Bhola">Bhola</option>
                             <option value="Jhalokati">Jhalokati</option>
                             <option value="Patuakhali ">Patuakhali </option>
                             <option value="Pirojpur">Pirojpur</option>
                             <option value="Bandarban">Bandarban</option>
                             <option value="Chandpur">Chandpur</option>
                             <option value="Chittagong">Chittagong</option>
                             <option value="Comilla">Comilla</option>
                             <option value="Cox's Bazar">Cox's Bazar</option>
                             <option value="Feni">Feni</option>
                             <option value="Khagrachhari">Khagrachhari</option>
                             <option value="Lakshmipur">Lakshmipur</option>
                             <option value="Noakhali">Noakhali</option>
                             <option value="Rangamati">Rangamati</option>
                             <option value="Dhaka">Dhaka</option>
                             <option value="Faridpur">Faridpur</option>
                             <option value="Gazipur">Gazipur</option>
                             <option value="Gopalganj">Gopalganj</option>
                             <option value="Kishoreganj">Kishoreganj</option>
                             <option value="Madaripur">Madaripur</option>
                             <option value="Manikganj">Manikganj</option>
                             <option value="Munshiganj">Munshiganj</option>
                             <option value="Narayanganj">Narayanganj</option>
                             <option value="Narsingdi">Narsingdi</option>
                             <option value="Rajbari">Rajbari</option>
                             <option value="Shariatpur">Shariatpur</option>
                             <option value="Tangail">Tangail</option>
                             <option value="Bagerhat">Bagerhat</option>
                             <option value="Chuadanga">Chuadanga</option>
                             <option value="Jashore">Jashore</option>
                             <option value="Jhenaidah">Jhenaidah</option>
                             <option value="Khulna">Khulna</option>
                             <option value="Kushtia">Kushtia</option>
                             <option value="Magura">Magura</option>
                             <option value="Meherpur">Meherpur</option>
                             <option value="Narail">Narail</option>
                             <option value="Satkhira">Satkhira</option>
                             <option value="Jamalpur">Jamalpur</option>
                             <option value="Mymensingh">Mymensingh</option>
                             <option value="Netrokona">Netrokona</option>
                             <option value="Sherpur">Sherpur</option>
                             <option value="Bogura">Bogura</option>
                             <option value="Joypurhat">Joypurhat</option>
                             <option value="Naogaon">Naogaon</option>
                             <option value="Natore">Natore</option>
                             <option value="Chapai Nawabganj	">Chapai Nawabganj	</option>
                             <option value="Pabna">Pabna</option>
                             <option value="Rajshahi">Rajshahi</option>
                             <option value="Sirajganj">Sirajganj</option>
                             <option value="Dinajpur">	Dinajpur</option>
                             <option value="Gaibandha">Gaibandha</option>
                             <option value="Kurigram">Kurigram</option>
                             <option value="Lalmonirhat">Lalmonirhat</option>
                             <option value="Nilphamari">Nilphamari</option>
                             <option value="Panchagarh">Panchagarh</option>
                             <option value="Rangpur">Rangpur</option>
                             <option value="Thakurgaon">Thakurgaon</option>
                             <option value="Brahmanbaria">Habiganj</option>
                             <option value="Moulvibazar">Moulvibazar</option>
                             <option value="Sunamganj">Sunamganj</option>
                             <option value="Sylhet">Sylhet</option>
                             

                        </select>

                       </div>
                     </div>
                 
                   </div>
                   <div class="row">
                   <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">Upozela </label>
                         <input placeholder="Enter Your Frist Name " name="agent_s_district" id="agent_s_district" type="text" class="form-control" required>
                       </div>
                     </div>
                   </div>
                   <div class="row">
                   <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">agent_ref </label>
                         <input placeholder="Enter Your Frist Name " name="agent_ref" id="agent_ref" type="text" class="form-control" required>
                       </div>
                     </div>
                   </div>
                   <div class="row">
                   <div class="col-md-12">
                       <div class="form-group">
                         <label class="bmd-label-floating">Agent Balace </label>
                         <input placeholder="Enter Your Frist Name " value="0" name="agent_balance" id="agent_balance" type="number" class="form-control" required>
                       </div>
                     </div>
                   </div>
                  
                   
                  
                     
                   
                  <button name="submit" type="submit" id="submit" class="btn btn-primary pull-right"> Add agent </button>

                   <div class="clearfix"></div>
                 </form>
               </div>
             </div>
           </div>
           
         </div>
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl">
                <div
                  class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
                  <div class="text-body">
                    ©
                    <script>
                      document.write(new Date().getFullYear());
                    </script>
                    , made with ❤️ by
                    <a href="https://www.facebook.com/profile.php?id=100011410499291" target="_blank" class="footer-link">Mastermind Shehab</a>
                  </div>
                 
                </div>
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

   

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/js/menu.js"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>
    <!-- Data Tablels Plugin -->
     <script src="https://code.jquery.com/jquery-3.7.1.js" > </script>
     <script src="https://cdn.datatables.net/2.1.4/js/dataTables.js" > </script>
     
     <script>
        $(document).ready(function(){
            $('#example ').DataTable();
        })
     </script>

     <script>
     $(document).ready(function(){
   $("#submit").click(function (event){
      event.preventDefault(); // Prevent the form from submitting normally
       
      var data = $("#agent_form").serialize();
      $.ajax({
         type: "POST",
         url: "agent_add.php",
         data: data,
         success: function(data){
            alert(data); // Show the response in an alert
         },
         error: function(xhr, status, error){
            // alert("An error occurred: " + error); 
            console.log(error)// Handle errors
         }
      });
   });
});

     </script>

  </body>
</html>

