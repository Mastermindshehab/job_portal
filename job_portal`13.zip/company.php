<?php
session_start();
if(isset($_SESSION['company_email'])){


}else{
  header('location:company_login.php?ss');
}

?>

<?php

include("include/header.php")
?>

 
<?php
include("connection/db.php");
$company_email=$_SESSION['company_email'];


$company_query=mysqli_query($dbconnect,"SELECT * from company where `company_email`='$company_email'");
 
while($companyprofiledata=mysqli_fetch_assoc($company_query)){
$company_id=$companyprofiledata['company_id'];
$company_name=$companyprofiledata['company_name'];
$company_email=$companyprofiledata['company_email'];
$company_number=$companyprofiledata['company_phone'];
$company_addrs=$companyprofiledata['company_addrs'];
$company_category=$companyprofiledata['company_category'];
$company_about=$companyprofiledata['company_about'];
$company_skill=$companyprofiledata['company_skill'];
$company_ref_id=$companyprofiledata['ref_id'];
$Date=$companyprofiledata['Date'];
}

$company_post_query=mysqli_query($dbconnect,"SELECT * from company_post where `company_id`='$company_id'");
 
function limit_characters($text, $limit) {
  return (strlen($text) > $limit) ? substr($text, 0, $limit) . '...' : $text;
}

?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <title>JobPortal - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ti-icons@0.1.2/css/themify-icons.css">
 <link rel="stylesheet" href="css/company.css">
  </head>
  <body>
    
	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand " href="index.html"  > <span style="color:green;" >BD</span> <span style="color:blue" >Trusth</span> <span style="color:black">Job</span> </a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="index.html" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="about.html" class="nav-link">Job Company</a></li>
	          <li class="nav-item"><a href="blog.html" class="nav-link">User</a></li>
	          <li class="nav-item"><a href="contact.html" class="nav-link">Agent</a></li>
    
	          <li class="nav-item cta mr-md-2">
            <div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   LOGIN
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="agent_profile.php">Agent Profile</a>
    <a class="dropdown-item" href="company_singout.php">SIGN OUT </a>
    <a class="dropdown-item" href="#">Company</a>
    <a class="dropdown-item" href="company.php">company profile</a>
  </div>
</div>
            </li>
	          <li class="nav-item cta mr-md-2"><a href="new-post.html" class="nav-link">Post a Job</a></li>
	          <li class="nav-item cta cta-colored"><a href="job-post.html" class="nav-link">Want a Job</a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
       
      </div>
    </div>

    <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-4 mb-5 mb-lg-0 wow fadeIn">
            <div class="card border-0 shadow">
                <img src="images/image_7.jpg" alt="...">
                <div class="card-body p-1-9 p-xl-5">
                    <div class="mb-4">
                        <h3 class="h4 mb-0"><?php echo $company_name ?></h3>
                        
                    <span class="text-primary"> <a href="company_singout.php">SING OUT</a> </span>
                    </div>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-3"><a href="company/company_dashboard.php">Company Dashboard</a></li>
                        <li class="mb-3"><a href="#!"> Add Job post   </a></li>
                        <li class="mb-3"><a href="#!"> Add  Normal Post   </a></li>
                        <li><a href="#!"><i class="fas fa-map-marker-alt display-25 me-3 text-secondary"></i> <?php echo $company_addrs ?> </a></li>
                    </ul>
                    <ul class="social-icon-style2 ps-0">
                        <li><a href="#!" class="rounded-3"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#!" class="rounded-3"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#!" class="rounded-3"><i class="fab fa-youtube"></i></a></li>
                        <li><a href="#!" class="rounded-3"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="ps-lg-1-6 ps-xl-5">
            <div class="mb-5 wow fadeIn">
                    <div class="text-start mb-1-6 wow fadeIn">
                        <h2 class="h1 mb-0 text-primary"> company personal info  </h2>
                    </div>
                    <h4> Name: <?php echo $company_name ?> </h4>
                    <h4> Email:<?php echo $company_email ?></h4>
                    <h4> Phone Number : <?php echo $company_number ?> </h4>
                    <h4> company Location: <?php echo $company_addrs ?> </h4>
                    <h4> Company Type: <?php echo $company_category ?> </h4>
                    <h4> Ref Id: <?php echo $company_ref_id ?> </h4>
                </div>
                <div class="mb-5 wow fadeIn">
                    <div class="text-start mb-1-6 wow fadeIn">
                        <h2 class="h1 mb-0 text-primary"> ABOUT </h2>
                    </div>
                
                    <p class="mb-0"> <?php echo $company_about ?> </p>
                </div>
                   
                <div class="wow fadeIn">
                    <div class="text-start mb-1-6 wow fadeIn">
                        <h2 class="mb-0 text-primary">#Skills</h2>
                    </div>
                    <p class="mb-4"> <?php echo $company_skill ?>  </p>
                  
                </div>
             
                <div class="mb-5 wow fadeIn">
                    <div class="text-start mb-1-6 wow fadeIn">
                        <h2 class="mb-0 text-primary"> Companies normal post  </h2>
                    </div>
                    <div class="row mt-n4">
                 
                       
                        <?php while ($company_post_data = mysqli_fetch_assoc($company_post_query)) { ?>
                                <div class="col-sm-6 col-xl-4 mt-4">
                                    <div class="card text-center border-0 rounded-3">
                                        <div class="card-body">
                                            <img class="ti-bookmark-alt icon-box medium rounded-3 mb-4" style="width: 80px; height: 80px;" src="company/img/<?php echo $company_post_data['post_photo']; ?>" alt=""> 
                                            <h3 class="h5 mb-3"><?php echo htmlspecialchars($company_post_data['post_title']); ?></h3>
                                            <p class="mb-0">
                                                <?php
                                                
                                                echo limit_characters($company_post_data['post_content'], 50);
                                                ?>
                                               
                                            </p>
                                           
                    <div class="btn-group">
                      

                      <a href="company_post_profile.php?view=<?php echo $company_post_data['c_post_id'] ?>" class="btn btn-success">  <span class="" >  <i class="bi bi-trash"> show details  </i>   </span> </a>
                    </div>
                  
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                    </div>
                </div>


                <div class="mb-5 wow fadeIn">
                    <div class="text-start mb-1-6 wow fadeIn">
                        <h2 class="mb-0 text-primary"> Job   Post </h2>
                    </div>
                    <div class="row mt-n4">
                        <div class="col-sm-6 col-xl-4 mt-4">
                            <div class="card text-center border-0 rounded-3">
                                <div class="card-body">
                                    <i class="ti-bookmark-alt icon-box medium rounded-3 mb-4"></i>
                                    <h3 class="h5 mb-3">Seb Development </h3>
                                    <p class="mb-0">University of defgtion, fecat complete ME of synage</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-4 mt-4">
                            <div class="card text-center border-0 rounded-3">
                                <div class="card-body">
                                    <i class="ti-pencil-alt icon-box medium rounded-3 mb-4"></i>
                                    <h3 class="h5 mb-3">Career Start</h3>
                                    <p class="mb-0">After complete engineer join HU Signage Ltd as a project manager</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xl-4 mt-4">
                            <div class="card text-center border-0 rounded-3">
                                <div class="card-body">
                                    <i class="ti-medall-alt icon-box medium rounded-3 mb-4"></i>
                                    <h3 class="h5 mb-3">Experience</h3>
                                    <p class="mb-0">About 20 years of experience and professional in signage</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
              
            </div>
        </div>
    </div>
</div>
    
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About</h2>
              <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Employers</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">How it works</a></li>
                <li><a href="#" class="py-2 d-block">Register</a></li>
                <li><a href="#" class="py-2 d-block">Post a Job</a></li>
                <li><a href="#" class="py-2 d-block">Advance Skill Search</a></li>
                <li><a href="#" class="py-2 d-block">Recruiting Service</a></li>
                <li><a href="#" class="py-2 d-block">Blog</a></li>
                <li><a href="#" class="py-2 d-block">Faq</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Workers</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">How it works</a></li>
                <li><a href="#" class="py-2 d-block">Register</a></li>
                <li><a href="#" class="py-2 d-block">Post Your Skills</a></li>
                <li><a href="#" class="py-2 d-block">Job Search</a></li>
                <li><a href="#" class="py-2 d-block">Emploer Search</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">203 Fake St. Mountain View, San Francisco, California, USA</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@yourdomain.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>