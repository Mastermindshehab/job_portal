<?php
session_start();
include("connection/db.php");

// Ensure that session is set
if (!isset($_SESSION['company_email'])) {
    header("location:../../company_login.php"); // Redirect to login if session is not set
    exit();
}

$company_email = mysqli_real_escape_string($dbconnect, $_SESSION['company_email']);

$company_name = mysqli_real_escape_string($dbconnect, $_POST['company_name']);
$company_phone = mysqli_real_escape_string($dbconnect, $_POST['company_phone']);
$company_addrs = mysqli_real_escape_string($dbconnect, $_POST['company_addrs']);
$company_category = mysqli_real_escape_string($dbconnect, $_POST['company_category']);
$company_about = mysqli_real_escape_string($dbconnect, $_POST['company_about']);
$company_skill = mysqli_real_escape_string($dbconnect, $_POST['company_skill']);

$query = mysqli_query($dbconnect, "UPDATE company 
SET 
    company_name = '$company_name', 
    company_phone = '$company_phone', 
    company_addrs = '$company_addrs', 
    company_category = '$company_category',
    company_about = '$company_about',
    company_skill = '$company_skill'
WHERE company_email = '$company_email'");

if ($query) {
    header("location:../contact_info.php?com_Update_success");
    exit();
} else {
    header("location:../contact_info.php?c_Update_failed");
    exit();
}
?>
