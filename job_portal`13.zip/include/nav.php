<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand " href="index.php"  > <span style="color:green;" >BD</span> <span style="color:blue" >Trusth</span> <span style="color:black">Job</span> </a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="company_profile.php" class="nav-link">Job Company</a></li>
	          <li class="nav-item"><a href="user.php" class="nav-link">User</a></li>
	          <li class="nav-item"><a href="agent.php" class="nav-link">Agent</a></li>
    
	          <li class="nav-item cta mr-md-2">
            <div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
   LOGIN
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="agent_profile.php">Agent Profile</a>
    <a class="dropdown-item" href="agent_sign_out.php">SIGN OUT </a>
    <a class="dropdown-item" href="user.php">User Profile</a>
    <a class="dropdown-item" href="company.php">company profile</a>
  </div>
</div>
            </li>
	          <li class="nav-item cta mr-md-2"><a href="new-post.html" class="nav-link">Post a Job</a></li>
	          <li class="nav-item cta cta-colored"><a href="job-post.html" class="nav-link">Want a Job</a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>