<?php

$dbhost="localhost";
$dbuser="mastermind1@";
$dbpassword="Mastermind@";
$db_name="job_portal";
 
$dbconnect=mysqli_connect($dbhost,$dbuser,$dbpassword,$db_name);
if($dbconnect==false){
    echo "database is not connected";
}




?>