<?php
require_once('connection/db.php');


$agent_username=$_REQUEST['agent_username'];
$agent_pwt=$_REQUEST['agent_password'];

$agent_Login_query=mysqli_query($dbconnect,"SELECT * FROM `agent` where  `agent_id`='$agent_username' and `agent_password`='$agent_pwt' ");
 
if(mysqli_num_rows($agent_Login_query)==1){
    session_start();

    $_SESSION['session_id']=session_id();
    $_SESSION['agent_username']=$agent_username; 
    $_SESSION['agent_password']=$agent_pwt;

    header('Location:agent_profile.php');

 
}else{
    header('Location:agent_login.php?agenterror!');


}

?>