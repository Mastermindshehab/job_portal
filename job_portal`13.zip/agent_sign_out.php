<?Php
session_start();
session_unset();
session_destroy();
header('location:agent_login.php');

?>