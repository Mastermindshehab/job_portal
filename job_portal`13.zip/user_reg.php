<?php
session_start();
?>
<!doctype html>
<html lang="en">

<head> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">



  <title>Signin Template for admin </title>

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Custom styles for this template -->
  <link href="css/admin_login.css" rel="stylesheet">
  <script src="js/admin_login.js"></script>
</head>

<body class="text-center">
 <div class="container">
  <div class="row">
    <div class=" col-md-12 col-lg-6 "  style="margin-top:80px; margin:auto; padding-top:40px" >
       <img class="mb-4" src="images/logo/logo.jpg" alt="" width="102" height="102">
    <form class="form-signin" action="admin/user_reg_req_core.php" method="POST"  id="company_form" name="company_form">
   
    <h1 class="h3 mb-3 font-weight-normal">Please sign up </h1>
    <label for="" class="sr-only">Name </label>
    <input type="text" id="user_name" name="user_name" class="form-control" 
    placeholder="User name " required autofocus>
    <label for="inputEmail" class="sr-only"> user Email </label>
    <input type="email" id="user_email" name="user_email" class="form-control" 
    placeholder=" User Email address" required autofocus>
    
    <label for="" class="sr-only"> User Id </label>
    <input type="text" id="user_id" name="user_id" class="form-control" 
    placeholder=" Type user_id " required autofocus>
    <label for="inputPassword" id="pass" name="pass" class="sr-only"> user Password </label>
    <input type="password" id="user_pass" name="user_pass" class="form-control" placeholder="Password" required>
    <label for="" class="sr-only text-dark "> user  Phone number </label>
    <input type="number" id="User_phone" name="user_phone" class="form-control" 
    placeholder="type your phone number  " required autofocus>
    <label for="" class="sr-only"> Date of birth </label>
    <input type="text" id="user_date_of_birth" name="user_date_of_birth" class="form-control" 
    placeholder=" date of birth yyyy-mm-dd  " required autofocus>
    <label for="" class="sr-only ">  address </label>
    <input type="text" id="user_addrs" name="user_addrs" class="form-control" 
    placeholder=" type your address detail explain  " required autofocus>
    <label style="float:left" for="" class="align-items-left">  gender  </label>
    <br/>
    <br/>
    <select style="float:left;" class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="user_gender" id="user_gender">
      <option value="dhaka">selected</option>
      <option value="male">male</option>
      <option value="female">female</option>
                            
                             

                        </select>
                        <br>
                        <br>

                        <label style="float: left;" for="" class=" ">  payment amount (200 Taka only ) </label>
    <input type="number" value="200" id="user_payment_amount" name="user_payment_amount" class="form-control" 
    placeholder=" Payment amount  " required autofocus>

    <label for="" style="float: left;" class=" ">  payment confirm number   </label>
    <br>
    <br>
    <p style="float: left; color:green;font-weight:800" > 01739171424 (BIKASH PERSONAL) </p>
    <input type="number" id="u_payment_c_number" name="u_payment_c_number" class="form-control" 
    placeholder=" typer your  Payment confirm Number    " required autofocus>
 
    <label for="inputEmail" class="sr-only"> ref id </label>
    <input type="text" id="ref_id" name="ref_id" class="form-control" 
    placeholder="type agent ref id   " required autofocus>
    <p style='color:green;'><?php if (isset($_REQUEST['userReqPending_success'])){
                                             echo "information insert successfull wait admin approval ";
                                    }?>
                                    </p>

                                      <p>  Already yet  Account ? <span> <a href="" > LOGIN  here </a> </span> </p>
   <button name="submit" type="submit" id="" class="btn btn-primary pull-right"> Submit </button>

    <p class="mt-5 mb-3 text-muted">&copy; 2024-2025</p>
  </form>
    </div>
  </div>


  
 </div>




</body>

</html>
<script>
        $(document).ready(function(){
            $('#example ').DataTable();
        })
     </script>

     <script>
     $(document).ready(function(){
   $("#submit").click(function (event){
      event.preventDefault(); // Prevent the form from submitting normally
       
      var data = $("#company_form").serialize();
      $.ajax({
         type: "POST",
         url: "",
         data: data,
         success: function(data){
            alert(data); // Show the response in an alert
         },
         error: function(xhr, status, error){
            alert("An error occurred: " + error); 
            console.log(error)// Handle errors
         }
      });
   });
});

     </script>