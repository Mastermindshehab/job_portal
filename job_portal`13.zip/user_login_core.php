<?php
require_once('connection/db.php');


$user_id=$_REQUEST['user_id'];
$user_pass=$_REQUEST['user_pass'];

$user_login_query=mysqli_query($dbconnect,"SELECT * FROM `user` where  `user_id`='$user_id' and `user_pass`='$user_pass' ");
 
if(mysqli_num_rows($user_login_query)==1){
    session_start();

    $_SESSION['session_id']=session_id();
    $_SESSION['user_id']=$user_id;
    $_SESSION['user_pass']=$user_pass;

    header('Location:user.php');

 
}else{
    header('Location:user_login.php?userLoginerror!');


}

?>