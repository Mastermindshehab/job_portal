<?php
require_once('connection/db.php');


$company_email=$_REQUEST['company_email'];
$company_pass=$_REQUEST['company_pass'];

$agent_Login_query=mysqli_query($dbconnect,"SELECT * FROM `company` where  `company_email`='$company_email' and `company_pass`='$company_pass' ");
 
if(mysqli_num_rows($agent_Login_query)==1){
    session_start();

    $_SESSION['session_id']=session_id();
    $_SESSION['company_email']=$company_email;
    $_SESSION['company_pass']=$company_pass;

    header('Location:company.php');

 
}else{
    header('Location:company_login.php?agenterror!');


}

?>