<?php
session_start();
?>
<!doctype html>
<html lang="en">

<head> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">



  <title>Signin Template for admin </title>

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Custom styles for this template -->
  <link href="css/admin_login.css" rel="stylesheet">
  <script src="js/admin_login.js"></script>
</head>

<body class="text-center">
 <div class="container">
  <div class="row">
    <div class=" col-md-12 col-lg-6 "  style="margin-top:80px; margin:auto; padding-top:40px" >
       <img class="mb-4" src="images/logo/logo.jpg" alt="" width="102" height="102">
    <form class="form-signin" action="company_add.php" method="POST"  id="company_form" name="company_form">
   
    <h1 class="h3 mb-3 font-weight-normal">Please sign up </h1>
    <label for="inputEmail" class="sr-only">Company Name</label>
    <input type="text" id="company_name" name="company_name" class="form-control" 
    placeholder="companny name " required autofocus>
    <label for="inputEmail" class="sr-only"> Company Email </label>
    <input type="email" id="company_email" name="company_email" class="form-control" 
    placeholder="Email address" required autofocus>
    <label for="inputPassword" id="pass" name="pass" class="sr-only"> Password</label>
    <input type="password" id="company_pass" name="company_pass" class="form-control" placeholder="Password" required>
    <label for="inputEmail" class="sr-only"> Company Phone </label>
    <input type="number" id="company_phone" name="company_phone" class="form-control" 
    placeholder="Companny phone " required autofocus>
    <label for="inputEmail" class="sr-only"> Company address </label>
    <input type="text" id="company_addrs" name="company_addrs" class="form-control" 
    placeholder=" address" required autofocus>
    <label for="inputEmail" class="sr-only"> Company Category </label>
    <input type="text" id="company_category" name="company_category" class="form-control" 
    placeholder="Company Category" required autofocus>
    <label for="inputEmail" class="sr-only"> Agent ref id </label>
    <input type="text" id="agent_ref" name="agent_ref" class="form-control" 
    placeholder="ref id " required autofocus>
    <p style='color:red;'><?php if (isset($_REQUEST['c_reg_faild!'])){
                                             echo "agent id or password is wrong ! ";
                                    }?></p>
                                      <p>  Already yet  Account ? <span> <a href="company_login.php" > LOGIN  here </a> </span> </p>
   <button name="submit" type="submit" id="" class="btn btn-primary pull-right"> Submit </button>

    <p class="mt-5 mb-3 text-muted">&copy; 2024-2025</p>
  </form>
    </div>
  </div>


  
 </div>




</body>

</html>
<script>
        $(document).ready(function(){
            $('#example ').DataTable();
        })
     </script>

     <script>
     $(document).ready(function(){
   $("#submit").click(function (event){
      event.preventDefault(); // Prevent the form from submitting normally
       
      var data = $("#company_form").serialize();
      $.ajax({
         type: "POST",
         url: "",
         data: data,
         success: function(data){
            alert(data); // Show the response in an alert
         },
         error: function(xhr, status, error){
            alert("An error occurred: " + error); 
            console.log(error)// Handle errors
         }
      });
   });
});

     </script>